class DclCamera:
    def __init__(self, model, dark, satu, rdsu, gdsu, bdsu, exte):
        self.model = model
        self.dark = dark
        self.satu = satu
        self.rdsu = rdsu
        self.gdsu = gdsu
        self.bdsu = bdsu
        self.exte = exte
