Python version of Digital Camera Luminance


